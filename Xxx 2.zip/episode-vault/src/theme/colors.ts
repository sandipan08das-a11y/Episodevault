export const colors = {
  background: '#0A0A0A',
  card: '#1A1A1A',
  cardAlt: '#222222',
  border: '#2A2A2A',
  text: '#F5F5F5',
  textMuted: '#A0A0A0',
  accent: '#E50914',
  accentMuted: '#7A0A10',
  success: '#2ECC71',
  warning: '#F5A623',
  danger: '#FF4B4B',
};

export const radius = {
  sm: 8,
  md: 14,
  lg: 20,
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
};
