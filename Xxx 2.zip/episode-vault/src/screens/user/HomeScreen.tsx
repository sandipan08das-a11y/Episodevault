import React, { useCallback, useEffect, useState } from 'react';
import {
  View,
  Text,
  FlatList,
  Image,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { useAuth } from '../../contexts/AuthContext';
import { fetchPublishedEpisodes } from '../../services/episodes';
import { fetchMyPurchases } from '../../services/payments';
import { Episode } from '../../types';
import { colors, radius, spacing } from '../../theme/colors';

export default function HomeScreen({ navigation }: any) {
  const { session } = useAuth();
  const [episodes, setEpisodes] = useState<Episode[]>([]);
  const [unlockedIds, setUnlockedIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setError(null);
    const [{ data: eps, error: epsError }, purchasesResult] = await Promise.all([
      fetchPublishedEpisodes(),
      session?.user ? fetchMyPurchases(session.user.id) : Promise.resolve({ data: [], error: null }),
    ]);
    if (epsError) setError(epsError);
    setEpisodes(eps);
    setUnlockedIds(new Set(purchasesResult.data.map((p) => p.episode_id)));
    setLoading(false);
    setRefreshing(false);
  }, [session]);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const onRefresh = () => {
    setRefreshing(true);
    load();
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color={colors.accent} />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      {error ? <Text style={styles.errorBanner}>{error}</Text> : null}
      <FlatList
        data={episodes}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ padding: spacing.md }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.accent} />}
        ListEmptyComponent={
          <View style={styles.center}>
            <Text style={styles.emptyText}>No episodes available yet.</Text>
          </View>
        }
        renderItem={({ item }) => {
          const unlocked = unlockedIds.has(item.id);
          return (
            <TouchableOpacity
              style={styles.card}
              activeOpacity={0.85}
              onPress={() => navigation.navigate('EpisodeDetails', { episodeId: item.id })}
            >
              {item.thumbnail_url ? (
                <Image source={{ uri: item.thumbnail_url }} style={styles.thumbnail} />
              ) : (
                <View style={[styles.thumbnail, styles.thumbnailPlaceholder]}>
                  <Text style={{ color: colors.textMuted }}>No Image</Text>
                </View>
              )}
              <View style={styles.cardBody}>
                <Text style={styles.epNumber}>EPISODE {item.episode_number}</Text>
                <Text style={styles.title} numberOfLines={1}>{item.title}</Text>
                {item.description ? (
                  <Text style={styles.description} numberOfLines={2}>{item.description}</Text>
                ) : null}
                <View style={styles.row}>
                  {unlocked ? (
                    <>
                      <View style={[styles.badge, styles.badgeUnlocked]}>
                        <Text style={styles.badgeText}>UNLOCKED</Text>
                      </View>
                      <Text style={styles.watchNow}>Watch Now ▸</Text>
                    </>
                  ) : (
                    <>
                      <View style={[styles.badge, styles.badgeLocked]}>
                        <Text style={styles.badgeText}>LOCKED</Text>
                      </View>
                      <Text style={styles.price}>₹{item.price}</Text>
                    </>
                  )}
                </View>
              </View>
            </TouchableOpacity>
          );
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingTop: spacing.xl },
  emptyText: { color: colors.textMuted, fontSize: 14 },
  errorBanner: { color: colors.danger, textAlign: 'center', padding: spacing.sm },
  card: {
    backgroundColor: colors.card,
    borderRadius: radius.md,
    marginBottom: spacing.md,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: colors.border,
  },
  thumbnail: { width: '100%', height: 180, backgroundColor: colors.cardAlt },
  thumbnailPlaceholder: { alignItems: 'center', justifyContent: 'center' },
  cardBody: { padding: spacing.md },
  epNumber: { color: colors.textMuted, fontSize: 11, letterSpacing: 1, fontWeight: '700' },
  title: { color: colors.text, fontSize: 18, fontWeight: '700', marginTop: 4 },
  description: { color: colors.textMuted, fontSize: 13, marginTop: 6 },
  row: { flexDirection: 'row', alignItems: 'center', marginTop: spacing.sm, gap: spacing.sm },
  badge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: radius.sm },
  badgeLocked: { backgroundColor: colors.accentMuted },
  badgeUnlocked: { backgroundColor: '#144D2E' },
  badgeText: { color: '#fff', fontSize: 11, fontWeight: '700', letterSpacing: 0.5 },
  price: { color: colors.text, fontWeight: '700', fontSize: 14 },
  watchNow: { color: colors.accent, fontWeight: '700', fontSize: 14 },
});
