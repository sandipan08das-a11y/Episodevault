import React, { useCallback, useState } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet, ActivityIndicator, ScrollView } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { useAuth } from '../../contexts/AuthContext';
import { fetchEpisodeById } from '../../services/episodes';
import { isEpisodeUnlocked } from '../../services/payments';
import { Episode } from '../../types';
import { colors, radius, spacing } from '../../theme/colors';

export default function EpisodeDetailsScreen({ route, navigation }: any) {
  const { episodeId } = route.params;
  const { session } = useAuth();
  const [episode, setEpisode] = useState<Episode | null>(null);
  const [unlocked, setUnlocked] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useFocusEffect(
    useCallback(() => {
      let mounted = true;
      (async () => {
        setLoading(true);
        setError(null);
        const { data, error: fetchError } = await fetchEpisodeById(episodeId);
        if (!mounted) return;
        if (fetchError || !data) {
          setError(fetchError || 'Episode not found.');
          setLoading(false);
          return;
        }
        setEpisode(data);
        if (session?.user) {
          const isUnlocked = await isEpisodeUnlocked(session.user.id, episodeId);
          if (mounted) setUnlocked(isUnlocked);
        }
        setLoading(false);
      })();
      return () => {
        mounted = false;
      };
    }, [episodeId, session])
  );

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color={colors.accent} />
      </View>
    );
  }

  if (error || !episode) {
    return (
      <View style={styles.center}>
        <Text style={styles.errorText}>{error || 'Episode not found.'}</Text>
      </View>
    );
  }

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.background }}>
      {episode.thumbnail_url ? (
        <Image source={{ uri: episode.thumbnail_url }} style={styles.hero} />
      ) : (
        <View style={[styles.hero, styles.heroPlaceholder]} />
      )}
      <View style={styles.body}>
        <Text style={styles.epNumber}>EPISODE {episode.episode_number}</Text>
        <Text style={styles.title}>{episode.title}</Text>
        {episode.description ? <Text style={styles.description}>{episode.description}</Text> : null}

        <View style={styles.statusRow}>
          <View style={[styles.badge, unlocked ? styles.badgeUnlocked : styles.badgeLocked]}>
            <Text style={styles.badgeText}>{unlocked ? 'UNLOCKED' : 'LOCKED'}</Text>
          </View>
          {!unlocked && <Text style={styles.price}>₹{episode.price}</Text>}
        </View>

        {unlocked ? (
          <TouchableOpacity
            style={styles.primaryButton}
            onPress={() => navigation.navigate('VideoPlayer', { episodeId: episode.id })}
          >
            <Text style={styles.primaryButtonText}>Watch Episode</Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity
            style={styles.primaryButton}
            onPress={() => navigation.navigate('Payment', { episodeId: episode.id })}
          >
            <Text style={styles.primaryButtonText}>Unlock for ₹{episode.price}</Text>
          </TouchableOpacity>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background },
  errorText: { color: colors.danger },
  hero: { width: '100%', height: 260, backgroundColor: colors.cardAlt },
  heroPlaceholder: {},
  body: { padding: spacing.lg },
  epNumber: { color: colors.textMuted, fontSize: 12, fontWeight: '700', letterSpacing: 1 },
  title: { color: colors.text, fontSize: 24, fontWeight: '800', marginTop: 6 },
  description: { color: colors.textMuted, fontSize: 15, marginTop: spacing.md, lineHeight: 22 },
  statusRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, marginTop: spacing.lg },
  badge: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: radius.sm },
  badgeLocked: { backgroundColor: colors.accentMuted },
  badgeUnlocked: { backgroundColor: '#144D2E' },
  badgeText: { color: '#fff', fontSize: 12, fontWeight: '700', letterSpacing: 0.5 },
  price: { color: colors.text, fontWeight: '700', fontSize: 16 },
  primaryButton: {
    backgroundColor: colors.accent,
    borderRadius: radius.sm,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: spacing.xl,
  },
  primaryButtonText: { color: '#fff', fontWeight: '700', fontSize: 16 },
});
