import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ActivityIndicator } from 'react-native';
import { Video, ResizeMode } from 'expo-av';
import { useAuth } from '../../contexts/AuthContext';
import { fetchEpisodeById } from '../../services/episodes';
import { isEpisodeUnlocked } from '../../services/payments';
import { getSignedVideoViewUrl } from '../../services/media';
import { colors, spacing } from '../../theme/colors';

export default function VideoPlayerScreen({ route }: any) {
  const { episodeId } = route.params;
  const { session } = useAuth();
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;
    (async () => {
      setLoading(true);
      setError(null);

      if (!session?.user) {
        setError('You must be logged in to watch this episode.');
        setLoading(false);
        return;
      }

      try {
        // Always re-verify the purchase server-side before ever touching the
        // video URL. Do not trust navigation params or client state alone.
        const unlocked = await isEpisodeUnlocked(session.user.id, episodeId);
        if (!unlocked) {
          if (mounted) {
            setError('This episode is locked. Please complete payment and wait for admin approval.');
            setLoading(false);
          }
          return;
        }

        const { data, error: fetchError } = await fetchEpisodeById(episodeId);
        if (!mounted) return;
        if (fetchError || !data || !data.video_url) {
          setError('Unable to load this video.');
          setLoading(false);
          return;
        }

        // data.video_url holds the private R2 object KEY, not a playable
        // URL. Always exchange it for a freshly-signed, short-lived URL —
        // this call itself is gated by the purchase check above, and the
        // edge function never returns anything for unauthenticated callers.
        const { url: signedUrl, error: signError } = await getSignedVideoViewUrl(data.video_url);
        if (!mounted) return;
        if (signError || !signedUrl) {
          setError(signError || 'Unable to load this video.');
          setLoading(false);
          return;
        }
        setVideoUrl(signedUrl);
      } catch (e) {
        if (mounted) setError('Unable to load this video.');
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, [episodeId, session]);

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color={colors.accent} />
      </View>
    );
  }

  if (error || !videoUrl) {
    return (
      <View style={styles.center}>
        <Text style={styles.errorText}>{error || 'Unable to play this video.'}</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Video
        source={{ uri: videoUrl }}
        style={styles.video}
        useNativeControls
        resizeMode={ResizeMode.CONTAIN}
        onError={() => setError('Video playback error. Please try again later.')}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000', justifyContent: 'center' },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background, padding: spacing.lg },
  video: { width: '100%', aspectRatio: 16 / 9 },
  errorText: { color: colors.danger, textAlign: 'center' },
});
