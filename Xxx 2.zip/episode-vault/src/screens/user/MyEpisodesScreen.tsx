import React, { useCallback, useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, ActivityIndicator, RefreshControl } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { useAuth } from '../../contexts/AuthContext';
import { fetchMyPaymentRequests } from '../../services/payments';
import { fetchEpisodeById } from '../../services/episodes';
import { PaymentRequest, Episode } from '../../types';
import { colors, radius, spacing } from '../../theme/colors';

interface Row {
  request: PaymentRequest;
  episode: Episode | null;
}

export default function MyEpisodesScreen({ navigation }: any) {
  const { session } = useAuth();
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!session?.user) {
      setLoading(false);
      setRefreshing(false);
      return;
    }
    setError(null);
    const { data: requests, error: reqError } = await fetchMyPaymentRequests(session.user.id);
    if (reqError) setError(reqError);

    const withEpisodes = await Promise.all(
      requests.map(async (request) => {
        const { data } = await fetchEpisodeById(request.episode_id);
        return { request, episode: data };
      })
    );
    setRows(withEpisodes);
    setLoading(false);
    setRefreshing(false);
  }, [session]);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const onRefresh = () => {
    setRefreshing(true);
    load();
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color={colors.accent} />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      {error ? <Text style={styles.errorBanner}>{error}</Text> : null}
      <FlatList
        data={rows}
        keyExtractor={(item) => item.request.id}
        contentContainerStyle={{ padding: spacing.md }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.accent} />}
        ListEmptyComponent={
          <View style={styles.center}>
            <Text style={styles.emptyText}>You haven't unlocked any episodes yet.</Text>
          </View>
        }
        renderItem={({ item }) => {
          const { request, episode } = item;
          return (
            <View style={styles.card}>
              <Text style={styles.title}>
                {episode ? `Episode ${episode.episode_number}: ${episode.title}` : 'Episode'}
              </Text>
              {request.status === 'pending' && (
                <Text style={styles.pending}>Payment verification pending</Text>
              )}
              {request.status === 'approved' && (
                <>
                  <Text style={styles.approved}>Episode unlocked</Text>
                  {episode && (
                    <TouchableOpacity
                      style={styles.watchButton}
                      onPress={() => navigation.navigate('VideoPlayer', { episodeId: episode.id })}
                    >
                      <Text style={styles.watchButtonText}>Watch Now</Text>
                    </TouchableOpacity>
                  )}
                </>
              )}
              {request.status === 'rejected' && <Text style={styles.rejected}>Payment rejected</Text>}
            </View>
          );
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingTop: spacing.xl },
  emptyText: { color: colors.textMuted, fontSize: 14 },
  errorBanner: { color: colors.danger, textAlign: 'center', padding: spacing.sm },
  card: {
    backgroundColor: colors.card,
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  title: { color: colors.text, fontSize: 16, fontWeight: '700' },
  pending: { color: colors.warning, marginTop: spacing.xs, fontSize: 13, fontWeight: '600' },
  approved: { color: colors.success, marginTop: spacing.xs, fontSize: 13, fontWeight: '600' },
  rejected: { color: colors.danger, marginTop: spacing.xs, fontSize: 13, fontWeight: '600' },
  watchButton: {
    backgroundColor: colors.accent,
    borderRadius: radius.sm,
    paddingVertical: 10,
    alignItems: 'center',
    marginTop: spacing.md,
  },
  watchButtonText: { color: '#fff', fontWeight: '700' },
});
