import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Image,
  Alert,
  ScrollView,
  Linking,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { useAuth } from '../../contexts/AuthContext';
import { fetchEpisodeById } from '../../services/episodes';
import { uploadPaymentScreenshot } from '../../services/storage';
import { submitPaymentRequest } from '../../services/payments';
import { Episode } from '../../types';
import { colors, radius, spacing } from '../../theme/colors';

const UPI_ID = 'paytmqrlx5zqedbf2@paytm';

export default function PaymentScreen({ route, navigation }: any) {
  const { episodeId } = route.params;
  const { session } = useAuth();
  const [episode, setEpisode] = useState<Episode | null>(null);
  const [loadingEpisode, setLoadingEpisode] = useState(true);
  const [utr, setUtr] = useState('');
  const [screenshotUri, setScreenshotUri] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    (async () => {
      const { data, error: fetchError } = await fetchEpisodeById(episodeId);
      if (fetchError || !data) {
        setError(fetchError || 'Episode not found.');
      } else {
        setEpisode(data);
      }
      setLoadingEpisode(false);
    })();
  }, [episodeId]);

  const amount = episode?.price ?? 20;

  const handlePayViaUpi = async () => {
    try {
      const upiUri = `upi://pay?pa=${UPI_ID}&pn=Episode%20Vault&am=${amount}&cu=INR`;
      const supported = await Linking.canOpenURL(upiUri);
      if (supported) {
        await Linking.openURL(upiUri);
      } else {
        Alert.alert(
          'No UPI App Found',
          'Please open Google Pay, PhonePe or another UPI app and pay to the UPI ID shown above.'
        );
      }
    } catch (e) {
      Alert.alert(
        'Unable to Open UPI App',
        'Please open Google Pay, PhonePe or another UPI app and pay to the UPI ID shown above.'
      );
    }
  };

  const handlePickScreenshot = async () => {
    try {
      const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) {
        setError('Please allow photo access to upload your payment screenshot.');
        return;
      }
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        quality: 0.7,
      });
      if (!result.canceled && result.assets?.[0]) {
        setScreenshotUri(result.assets[0].uri);
        setError(null);
      }
    } catch (e) {
      setError('Unable to select screenshot. Please try again.');
    }
  };

  const handleSubmit = async () => {
    setError(null);
    if (!utr.trim()) {
      setError('Please enter your UTR.');
      return;
    }
    if (!screenshotUri) {
      setError('Please select a payment screenshot.');
      return;
    }
    if (!session?.user) {
      setError('You must be logged in to submit a payment.');
      return;
    }
    if (!episode) {
      setError('Episode not found.');
      return;
    }

    setSubmitting(true);
    try {
      const ext = screenshotUri.split('.').pop()?.toLowerCase() || 'jpg';
      const { path, error: uploadError } = await uploadPaymentScreenshot(
        session.user.id,
        episode.id,
        screenshotUri,
        ext
      );
      if (uploadError || !path) {
        setError(uploadError || 'Screenshot upload failed.');
        setSubmitting(false);
        return;
      }

      const { error: submitError } = await submitPaymentRequest({
        user_id: session.user.id,
        episode_id: episode.id,
        amount,
        utr,
        screenshot_url: path,
      });

      if (submitError) {
        setError(submitError);
        setSubmitting(false);
        return;
      }

      setSubmitted(true);
    } catch (e) {
      setError('Payment submission failed.');
    } finally {
      setSubmitting(false);
    }
  };

  if (loadingEpisode) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color={colors.accent} />
      </View>
    );
  }

  if (submitted) {
    return (
      <View style={styles.center}>
        <Text style={styles.successTitle}>Payment submitted successfully.</Text>
        <Text style={styles.successSubtitle}>Your payment is waiting for admin verification.</Text>
        <TouchableOpacity style={styles.primaryButton} onPress={() => navigation.popToTop()}>
          <Text style={styles.primaryButtonText}>Back to Home</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.background }} contentContainerStyle={{ padding: spacing.lg }}>
      <Text style={styles.heading}>Unlock Episode</Text>
      <Text style={styles.amount}>Amount: ₹{amount}</Text>

      <View style={styles.upiBox}>
        <Text style={styles.upiLabel}>UPI ID</Text>
        <Text style={styles.upiValue}>{UPI_ID}</Text>
      </View>

      <TouchableOpacity style={styles.upiButton} onPress={handlePayViaUpi}>
        <Text style={styles.primaryButtonText}>Pay ₹{amount} via UPI</Text>
      </TouchableOpacity>

      <Text style={styles.instructions}>
        After completing payment, enter your UTR / Transaction ID and upload your payment screenshot.
      </Text>

      <Text style={styles.label}>UTR / Transaction ID</Text>
      <TextInput
        style={styles.input}
        value={utr}
        onChangeText={setUtr}
        placeholder="Enter UTR"
        placeholderTextColor={colors.textMuted}
      />

      <Text style={styles.label}>Payment Screenshot</Text>
      <TouchableOpacity style={styles.uploadBox} onPress={handlePickScreenshot}>
        {screenshotUri ? (
          <Image source={{ uri: screenshotUri }} style={styles.screenshotPreview} />
        ) : (
          <Text style={styles.uploadText}>Tap to select screenshot</Text>
        )}
      </TouchableOpacity>

      {error ? <Text style={styles.error}>{error}</Text> : null}

      <TouchableOpacity
        style={[styles.primaryButton, submitting && styles.buttonDisabled]}
        onPress={handleSubmit}
        disabled={submitting}
      >
        {submitting ? <ActivityIndicator color="#fff" /> : <Text style={styles.primaryButtonText}>Submit Payment</Text>}
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background, padding: spacing.lg },
  heading: { color: colors.text, fontSize: 22, fontWeight: '800' },
  amount: { color: colors.textMuted, fontSize: 15, marginTop: 4, marginBottom: spacing.lg },
  upiBox: {
    backgroundColor: colors.card,
    borderRadius: radius.md,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  upiLabel: { color: colors.textMuted, fontSize: 12, fontWeight: '700', letterSpacing: 0.5 },
  upiValue: { color: colors.text, fontSize: 16, fontWeight: '700', marginTop: 4 },
  upiButton: {
    backgroundColor: colors.accent,
    borderRadius: radius.sm,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: spacing.md,
  },
  instructions: { color: colors.textMuted, fontSize: 13, marginTop: spacing.lg, lineHeight: 19 },
  label: { color: colors.textMuted, fontSize: 13, marginTop: spacing.lg, marginBottom: spacing.xs },
  input: {
    backgroundColor: colors.card,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.border,
    color: colors.text,
    paddingHorizontal: spacing.md,
    paddingVertical: 12,
    fontSize: 15,
  },
  uploadBox: {
    backgroundColor: colors.card,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.border,
    borderStyle: 'dashed',
    minHeight: 140,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  uploadText: { color: colors.textMuted },
  screenshotPreview: { width: '100%', height: 200 },
  error: { color: colors.danger, marginTop: spacing.md, fontSize: 13 },
  primaryButton: {
    backgroundColor: colors.accent,
    borderRadius: radius.sm,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: spacing.xl,
    paddingHorizontal: spacing.xl,
  },
  buttonDisabled: { opacity: 0.6 },
  primaryButtonText: { color: '#fff', fontWeight: '700', fontSize: 16 },
  successTitle: { color: colors.text, fontSize: 20, fontWeight: '800', textAlign: 'center' },
  successSubtitle: { color: colors.textMuted, fontSize: 14, textAlign: 'center', marginTop: spacing.sm },
});
