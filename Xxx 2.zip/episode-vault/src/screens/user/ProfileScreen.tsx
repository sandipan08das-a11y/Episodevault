import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ActivityIndicator } from 'react-native';
import { useAuth } from '../../contexts/AuthContext';
import { colors, radius, spacing } from '../../theme/colors';

export default function ProfileScreen() {
  const { session, profile, signOut } = useAuth();
  const [loggingOut, setLoggingOut] = useState(false);

  const handleLogout = async () => {
    setLoggingOut(true);
    await signOut();
    setLoggingOut(false);
  };

  return (
    <View style={styles.container}>
      <View style={styles.card}>
        <Text style={styles.label}>Full Name</Text>
        <Text style={styles.value}>{profile?.full_name || '—'}</Text>

        <Text style={styles.label}>Email</Text>
        <Text style={styles.value}>{session?.user?.email || '—'}</Text>

        <Text style={styles.label}>Account Type</Text>
        <Text style={styles.value}>{profile?.role === 'admin' ? 'Admin' : 'User'}</Text>
      </View>

      <TouchableOpacity style={styles.logoutButton} onPress={handleLogout} disabled={loggingOut}>
        {loggingOut ? <ActivityIndicator color="#fff" /> : <Text style={styles.logoutText}>Log Out</Text>}
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: spacing.lg },
  card: {
    backgroundColor: colors.card,
    borderRadius: radius.md,
    padding: spacing.lg,
    borderWidth: 1,
    borderColor: colors.border,
    marginTop: spacing.lg,
  },
  label: { color: colors.textMuted, fontSize: 12, marginTop: spacing.md, letterSpacing: 0.5 },
  value: { color: colors.text, fontSize: 16, fontWeight: '600', marginTop: 4 },
  logoutButton: {
    backgroundColor: colors.danger,
    borderRadius: radius.sm,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: spacing.xl,
  },
  logoutText: { color: '#fff', fontWeight: '700', fontSize: 16 },
});
