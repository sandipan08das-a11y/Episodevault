import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  ScrollView,
  Switch,
  Alert,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { fetchEpisodeById, createEpisode, updateEpisode } from '../../services/episodes';
import { uploadEpisodeVideo, deleteEpisodeVideo } from '../../services/media';
import { colors, radius, spacing } from '../../theme/colors';

export default function AddEditEpisodeScreen({ route, navigation }: any) {
  const episodeId: string | undefined = route.params?.episodeId;
  const isEditing = !!episodeId;

  const [episodeNumber, setEpisodeNumber] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [thumbnailUrl, setThumbnailUrl] = useState('');
  const [videoKey, setVideoKey] = useState<string | null>(null);
  const [price, setPrice] = useState('20');
  const [isPublished, setIsPublished] = useState(true);

  const [loading, setLoading] = useState(isEditing);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [deletingVideo, setDeletingVideo] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!episodeId) return;
    (async () => {
      const { data, error: fetchError } = await fetchEpisodeById(episodeId);
      if (fetchError || !data) {
        setError(fetchError || 'Episode not found.');
      } else {
        setEpisodeNumber(String(data.episode_number));
        setTitle(data.title);
        setDescription(data.description || '');
        setThumbnailUrl(data.thumbnail_url || '');
        setVideoKey(data.video_url || null); // video_url column stores the private R2 object key
        setPrice(String(data.price));
        setIsPublished(data.is_published);
      }
      setLoading(false);
    })();
  }, [episodeId]);

  const handlePickAndUploadVideo = async () => {
    try {
      setError(null);
      const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) {
        setError('Please allow media access to upload a video.');
        return;
      }
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Videos,
        quality: 1,
      });
      if (result.canceled || !result.assets?.[0]) return;

      const asset = result.assets[0];
      const fileName = asset.fileName || `episode-${Date.now()}.mp4`;
      const contentType = asset.mimeType || 'video/mp4';

      setUploading(true);
      setUploadProgress(0);

      // If replacing an existing video, upload the new one first, then
      // clean up the old object so we never leave the episode without a
      // playable video if the upload fails.
      const { key, error: uploadError } = await uploadEpisodeVideo(
        asset.uri,
        fileName,
        contentType,
        (fraction) => setUploadProgress(fraction)
      );

      if (uploadError || !key) {
        setError(uploadError || 'Video upload failed.');
        setUploading(false);
        return;
      }

      const previousKey = videoKey;
      setVideoKey(key);
      setUploading(false);

      if (previousKey) {
        await deleteEpisodeVideo(previousKey);
      }
    } catch (e) {
      setError('Video upload failed.');
      setUploading(false);
    }
  };

  const handleDeleteVideo = () => {
    if (!videoKey) return;
    Alert.alert('Remove Video', 'Delete the uploaded video from storage?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          setDeletingVideo(true);
          const { error: deleteError } = await deleteEpisodeVideo(videoKey);
          setDeletingVideo(false);
          if (deleteError) {
            Alert.alert('Error', deleteError);
            return;
          }
          setVideoKey(null);
        },
      },
    ]);
  };

  const handleSave = async () => {
    setError(null);
    const epNum = parseInt(episodeNumber, 10);
    const priceNum = parseFloat(price);

    if (!title.trim()) {
      setError('Please enter a title.');
      return;
    }
    if (isNaN(epNum)) {
      setError('Please enter a valid episode number.');
      return;
    }
    if (isNaN(priceNum) || priceNum <= 0) {
      setError('Please enter a valid price.');
      return;
    }

    setSaving(true);
    const payload = {
      episode_number: epNum,
      title: title.trim(),
      description: description.trim() || null,
      thumbnail_url: thumbnailUrl.trim() || null,
      video_url: videoKey, // stores the private R2 object key, not a public URL
      price: priceNum,
      is_published: isPublished,
    };

    const result = isEditing
      ? await updateEpisode(episodeId as string, payload)
      : await createEpisode(payload as any);

    setSaving(false);
    if (result.error) {
      setError(result.error);
      return;
    }
    navigation.goBack();
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color={colors.accent} />
      </View>
    );
  }

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.background }} contentContainerStyle={{ padding: spacing.lg }}>
      <Text style={styles.label}>Episode Number</Text>
      <TextInput
        style={styles.input}
        value={episodeNumber}
        onChangeText={setEpisodeNumber}
        keyboardType="number-pad"
        placeholder="1"
        placeholderTextColor={colors.textMuted}
      />

      <Text style={styles.label}>Title</Text>
      <TextInput
        style={styles.input}
        value={title}
        onChangeText={setTitle}
        placeholder="Episode title"
        placeholderTextColor={colors.textMuted}
      />

      <Text style={styles.label}>Description</Text>
      <TextInput
        style={[styles.input, styles.multiline]}
        value={description}
        onChangeText={setDescription}
        placeholder="Episode description"
        placeholderTextColor={colors.textMuted}
        multiline
      />

      <Text style={styles.label}>Thumbnail URL</Text>
      <TextInput
        style={styles.input}
        value={thumbnailUrl}
        onChangeText={setThumbnailUrl}
        placeholder="https://..."
        placeholderTextColor={colors.textMuted}
        autoCapitalize="none"
      />

      <Text style={styles.label}>Video</Text>
      <View style={styles.videoBox}>
        {videoKey ? (
          <>
            <Text style={styles.videoStatus}>✓ Video uploaded</Text>
            <Text style={styles.videoKey} numberOfLines={1}>{videoKey}</Text>
            <View style={styles.videoActionsRow}>
              <TouchableOpacity
                style={styles.videoActionButton}
                onPress={handlePickAndUploadVideo}
                disabled={uploading || deletingVideo}
              >
                <Text style={styles.videoActionText}>Replace</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.videoActionButton, styles.deleteVideoButton]}
                onPress={handleDeleteVideo}
                disabled={uploading || deletingVideo}
              >
                {deletingVideo ? (
                  <ActivityIndicator color={colors.danger} size="small" />
                ) : (
                  <Text style={[styles.videoActionText, { color: colors.danger }]}>Delete</Text>
                )}
              </TouchableOpacity>
            </View>
          </>
        ) : uploading ? (
          <View style={{ alignItems: 'center', paddingVertical: spacing.md }}>
            <ActivityIndicator color={colors.accent} />
            <Text style={styles.uploadProgressText}>Uploading… {Math.round(uploadProgress * 100)}%</Text>
          </View>
        ) : (
          <TouchableOpacity style={styles.uploadButton} onPress={handlePickAndUploadVideo}>
            <Text style={styles.uploadButtonText}>Upload Video</Text>
          </TouchableOpacity>
        )}
      </View>

      <Text style={styles.label}>Price (₹)</Text>
      <TextInput
        style={styles.input}
        value={price}
        onChangeText={setPrice}
        keyboardType="decimal-pad"
        placeholder="20"
        placeholderTextColor={colors.textMuted}
      />

      <View style={styles.switchRow}>
        <Text style={styles.label}>Published</Text>
        <Switch
          value={isPublished}
          onValueChange={setIsPublished}
          trackColor={{ false: colors.border, true: colors.accentMuted }}
          thumbColor={isPublished ? colors.accent : '#888'}
        />
      </View>

      {error ? <Text style={styles.error}>{error}</Text> : null}

      <TouchableOpacity
        style={[styles.button, (saving || uploading) && styles.buttonDisabled]}
        onPress={handleSave}
        disabled={saving || uploading}
      >
        {saving ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>{isEditing ? 'Save Changes' : 'Create Episode'}</Text>}
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background },
  label: { color: colors.textMuted, fontSize: 13, marginTop: spacing.md, marginBottom: spacing.xs },
  input: {
    backgroundColor: colors.card,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.border,
    color: colors.text,
    paddingHorizontal: spacing.md,
    paddingVertical: 12,
    fontSize: 15,
  },
  multiline: { minHeight: 90, textAlignVertical: 'top' },
  videoBox: {
    backgroundColor: colors.card,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.md,
  },
  videoStatus: { color: colors.success, fontWeight: '700', fontSize: 14 },
  videoKey: { color: colors.textMuted, fontSize: 11, marginTop: 4 },
  videoActionsRow: { flexDirection: 'row', gap: spacing.sm, marginTop: spacing.md },
  videoActionButton: {
    backgroundColor: colors.cardAlt,
    borderRadius: radius.sm,
    paddingVertical: 8,
    paddingHorizontal: 14,
  },
  deleteVideoButton: {},
  videoActionText: { color: colors.text, fontWeight: '600', fontSize: 13 },
  uploadButton: { alignItems: 'center', paddingVertical: spacing.sm },
  uploadButtonText: { color: colors.accent, fontWeight: '700', fontSize: 15 },
  uploadProgressText: { color: colors.textMuted, marginTop: spacing.sm, fontSize: 13 },
  switchRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: spacing.md },
  error: { color: colors.danger, marginTop: spacing.md, fontSize: 13 },
  button: {
    backgroundColor: colors.accent,
    borderRadius: radius.sm,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: spacing.xl,
    marginBottom: spacing.xl,
  },
  buttonDisabled: { opacity: 0.6 },
  buttonText: { color: '#fff', fontWeight: '700', fontSize: 16 },
});
