import React, { useCallback, useState } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Image,
  Alert,
  RefreshControl,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import {
  fetchAllPaymentRequestsAdmin,
  approvePaymentRequest,
  rejectPaymentRequest,
} from '../../services/payments';
import { getSignedScreenshotUrl } from '../../services/storage';
import { PaymentRequest } from '../../types';
import { colors, radius, spacing } from '../../theme/colors';

export default function AdminPaymentsScreen() {
  const [requests, setRequests] = useState<PaymentRequest[]>([]);
  const [signedUrls, setSignedUrls] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setError(null);
    const { data, error: fetchError } = await fetchAllPaymentRequestsAdmin();
    if (fetchError) setError(fetchError);
    setRequests(data);

    const urlEntries = await Promise.all(
      data
        .filter((r) => r.screenshot_url)
        .map(async (r) => {
          const { url } = await getSignedScreenshotUrl(r.screenshot_url as string);
          return [r.id, url] as const;
        })
    );
    const urlMap: Record<string, string> = {};
    urlEntries.forEach(([id, url]) => {
      if (url) urlMap[id] = url;
    });
    setSignedUrls(urlMap);

    setLoading(false);
    setRefreshing(false);
  }, []);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const onRefresh = () => {
    setRefreshing(true);
    load();
  };

  const handleApprove = async (request: PaymentRequest) => {
    setBusyId(request.id);
    const { error: approveError } = await approvePaymentRequest(request);
    if (approveError) Alert.alert('Error', approveError);
    else await load();
    setBusyId(null);
  };

  const handleReject = async (request: PaymentRequest) => {
    setBusyId(request.id);
    const { error: rejectError } = await rejectPaymentRequest(request.id);
    if (rejectError) Alert.alert('Error', rejectError);
    else await load();
    setBusyId(null);
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color={colors.accent} />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      {error ? <Text style={styles.errorBanner}>{error}</Text> : null}
      <FlatList
        data={requests}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ padding: spacing.md }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.accent} />}
        ListEmptyComponent={
          <View style={styles.center}>
            <Text style={styles.emptyText}>No payment requests.</Text>
          </View>
        }
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={styles.userName}>{item.profiles?.full_name || 'Unknown user'}</Text>
            <Text style={styles.meta}>
              Episode {item.episodes?.episode_number}: {item.episodes?.title}
            </Text>
            <Text style={styles.meta}>Amount: ₹{item.amount}</Text>
            <Text style={styles.meta}>UTR: {item.utr}</Text>
            <Text style={styles.meta}>Date: {new Date(item.created_at).toLocaleString()}</Text>
            <Text style={[styles.statusText, statusStyle(item.status)]}>{item.status.toUpperCase()}</Text>

            {signedUrls[item.id] ? (
              <Image source={{ uri: signedUrls[item.id] }} style={styles.screenshot} />
            ) : (
              <Text style={styles.noScreenshot}>Screenshot unavailable</Text>
            )}

            {item.status === 'pending' && (
              <View style={styles.actionsRow}>
                <TouchableOpacity
                  style={[styles.actionButton, styles.approveButton]}
                  onPress={() => handleApprove(item)}
                  disabled={busyId === item.id}
                >
                  {busyId === item.id ? (
                    <ActivityIndicator color="#fff" size="small" />
                  ) : (
                    <Text style={styles.actionText}>APPROVE</Text>
                  )}
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.actionButton, styles.rejectButton]}
                  onPress={() => handleReject(item)}
                  disabled={busyId === item.id}
                >
                  <Text style={styles.actionText}>REJECT</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        )}
      />
    </View>
  );
}

function statusStyle(status: string) {
  if (status === 'approved') return { color: colors.success };
  if (status === 'rejected') return { color: colors.danger };
  return { color: colors.warning };
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingTop: spacing.xl },
  emptyText: { color: colors.textMuted, fontSize: 14 },
  errorBanner: { color: colors.danger, textAlign: 'center', padding: spacing.sm },
  card: {
    backgroundColor: colors.card,
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  userName: { color: colors.text, fontSize: 16, fontWeight: '700' },
  meta: { color: colors.textMuted, fontSize: 13, marginTop: 2 },
  statusText: { fontSize: 13, fontWeight: '700', marginTop: spacing.xs },
  screenshot: { width: '100%', height: 200, borderRadius: radius.sm, marginTop: spacing.sm, backgroundColor: colors.cardAlt },
  noScreenshot: { color: colors.textMuted, marginTop: spacing.sm, fontSize: 12 },
  actionsRow: { flexDirection: 'row', gap: spacing.sm, marginTop: spacing.md },
  actionButton: { flex: 1, borderRadius: radius.sm, paddingVertical: 12, alignItems: 'center' },
  approveButton: { backgroundColor: colors.success },
  rejectButton: { backgroundColor: colors.danger },
  actionText: { color: '#fff', fontWeight: '700', fontSize: 13 },
});
