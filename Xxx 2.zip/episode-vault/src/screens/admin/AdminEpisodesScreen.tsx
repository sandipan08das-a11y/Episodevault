import React, { useCallback, useState } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Alert,
  RefreshControl,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { fetchAllEpisodesAdmin, updateEpisode, deleteEpisode } from '../../services/episodes';
import { Episode } from '../../types';
import { colors, radius, spacing } from '../../theme/colors';

export default function AdminEpisodesScreen({ navigation }: any) {
  const [episodes, setEpisodes] = useState<Episode[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setError(null);
    const { data, error: fetchError } = await fetchAllEpisodesAdmin();
    if (fetchError) setError(fetchError);
    setEpisodes(data);
    setLoading(false);
    setRefreshing(false);
  }, []);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const onRefresh = () => {
    setRefreshing(true);
    load();
  };

  const togglePublish = async (episode: Episode) => {
    setBusyId(episode.id);
    const { error: updateError } = await updateEpisode(episode.id, { is_published: !episode.is_published });
    if (updateError) {
      Alert.alert('Error', updateError);
    } else {
      await load();
    }
    setBusyId(null);
  };

  const confirmDelete = (episode: Episode) => {
    Alert.alert('Delete Episode', `Delete "${episode.title}"? This cannot be undone.`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          setBusyId(episode.id);
          const { error: deleteError } = await deleteEpisode(episode.id);
          if (deleteError) Alert.alert('Error', deleteError);
          else await load();
          setBusyId(null);
        },
      },
    ]);
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color={colors.accent} />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      {error ? <Text style={styles.errorBanner}>{error}</Text> : null}
      <TouchableOpacity
        style={styles.addButton}
        onPress={() => navigation.navigate('AddEditEpisode', {})}
      >
        <Text style={styles.addButtonText}>+ Add Episode</Text>
      </TouchableOpacity>
      <FlatList
        data={episodes}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ padding: spacing.md }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.accent} />}
        ListEmptyComponent={
          <View style={styles.center}>
            <Text style={styles.emptyText}>No episodes available yet.</Text>
          </View>
        }
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={styles.title}>
              Episode {item.episode_number}: {item.title}
            </Text>
            <Text style={styles.meta}>₹{item.price} · {item.is_published ? 'Published' : 'Unpublished'}</Text>
            <View style={styles.actionsRow}>
              <TouchableOpacity
                style={styles.actionButton}
                onPress={() => navigation.navigate('AddEditEpisode', { episodeId: item.id })}
              >
                <Text style={styles.actionText}>Edit</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.actionButton}
                onPress={() => togglePublish(item)}
                disabled={busyId === item.id}
              >
                {busyId === item.id ? (
                  <ActivityIndicator color={colors.text} size="small" />
                ) : (
                  <Text style={styles.actionText}>{item.is_published ? 'Unpublish' : 'Publish'}</Text>
                )}
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.actionButton, styles.deleteButton]}
                onPress={() => confirmDelete(item)}
                disabled={busyId === item.id}
              >
                <Text style={[styles.actionText, { color: colors.danger }]}>Delete</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingTop: spacing.xl },
  emptyText: { color: colors.textMuted, fontSize: 14 },
  errorBanner: { color: colors.danger, textAlign: 'center', padding: spacing.sm },
  addButton: {
    backgroundColor: colors.accent,
    borderRadius: radius.sm,
    paddingVertical: 12,
    alignItems: 'center',
    margin: spacing.md,
  },
  addButtonText: { color: '#fff', fontWeight: '700' },
  card: {
    backgroundColor: colors.card,
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  title: { color: colors.text, fontSize: 16, fontWeight: '700' },
  meta: { color: colors.textMuted, fontSize: 13, marginTop: 4 },
  actionsRow: { flexDirection: 'row', gap: spacing.sm, marginTop: spacing.md },
  actionButton: {
    backgroundColor: colors.cardAlt,
    borderRadius: radius.sm,
    paddingVertical: 8,
    paddingHorizontal: 14,
  },
  deleteButton: {},
  actionText: { color: colors.text, fontWeight: '600', fontSize: 13 },
});
