import React, { useCallback, useState } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, ScrollView, RefreshControl } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { supabase } from '../../lib/supabase';
import { colors, radius, spacing } from '../../theme/colors';

interface Stats {
  totalUsers: number;
  totalEpisodes: number;
  pendingPayments: number;
  approvedPayments: number;
  totalPurchases: number;
}

export default function AdminDashboardScreen() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setError(null);
    try {
      const [users, episodes, pending, approved, purchases] = await Promise.all([
        supabase.from('profiles').select('id', { count: 'exact', head: true }),
        supabase.from('episodes').select('id', { count: 'exact', head: true }),
        supabase.from('payment_requests').select('id', { count: 'exact', head: true }).eq('status', 'pending'),
        supabase.from('payment_requests').select('id', { count: 'exact', head: true }).eq('status', 'approved'),
        supabase.from('purchases').select('id', { count: 'exact', head: true }),
      ]);

      if (users.error || episodes.error || pending.error || approved.error || purchases.error) {
        setError('Unable to load dashboard stats.');
      } else {
        setStats({
          totalUsers: users.count || 0,
          totalEpisodes: episodes.count || 0,
          pendingPayments: pending.count || 0,
          approvedPayments: approved.count || 0,
          totalPurchases: purchases.count || 0,
        });
      }
    } catch (e) {
      setError('Unable to load dashboard stats.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const onRefresh = () => {
    setRefreshing(true);
    load();
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color={colors.accent} />
      </View>
    );
  }

  const items = stats
    ? [
        { label: 'Total Users', value: stats.totalUsers },
        { label: 'Total Episodes', value: stats.totalEpisodes },
        { label: 'Pending Payments', value: stats.pendingPayments },
        { label: 'Approved Payments', value: stats.approvedPayments },
        { label: 'Total Purchases', value: stats.totalPurchases },
      ]
    : [];

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.background }}
      contentContainerStyle={{ padding: spacing.lg }}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.accent} />}
    >
      <Text style={styles.heading}>Dashboard</Text>
      {error ? <Text style={styles.error}>{error}</Text> : null}
      {items.map((item) => (
        <View key={item.label} style={styles.card}>
          <Text style={styles.value}>{item.value}</Text>
          <Text style={styles.label}>{item.label}</Text>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background },
  heading: { color: colors.text, fontSize: 24, fontWeight: '800', marginBottom: spacing.lg },
  error: { color: colors.danger, marginBottom: spacing.md },
  card: {
    backgroundColor: colors.card,
    borderRadius: radius.md,
    padding: spacing.lg,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  value: { color: colors.accent, fontSize: 32, fontWeight: '800' },
  label: { color: colors.textMuted, fontSize: 13, marginTop: 4 },
});
