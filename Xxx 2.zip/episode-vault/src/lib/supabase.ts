import 'react-native-url-polyfill/auto';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient } from '@supabase/supabase-js';

// Public, client-safe values only. NEVER put the service_role key here.
const SUPABASE_URL = 'https://vctzbxbmxckatjhijfye.supabase.co';
const SUPABASE_PUBLISHABLE_KEY = 'sb_publishable_y90-FpTEFmqJm0mDCaSe1g_Bk4i59tl';

export const supabase = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});
