import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useAuth } from '../contexts/AuthContext';
import { colors } from '../theme/colors';

import SplashScreen from '../screens/SplashScreen';
import LoginScreen from '../screens/auth/LoginScreen';
import SignupScreen from '../screens/auth/SignupScreen';
import UserTabNavigator from './UserTabNavigator';
import AdminTabNavigator from './AdminTabNavigator';

const AuthStack = createNativeStackNavigator();

function AuthStackNavigator() {
  return (
    <AuthStack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: colors.background },
        headerTintColor: colors.text,
        headerShadowVisible: false,
        contentStyle: { backgroundColor: colors.background },
      }}
    >
      <AuthStack.Screen name="Login" component={LoginScreen} options={{ title: 'Log In' }} />
      <AuthStack.Screen name="Signup" component={SignupScreen} options={{ title: 'Create Account' }} />
    </AuthStack.Navigator>
  );
}

export default function RootNavigator() {
  const { session, profile, loading } = useAuth();

  const navTheme = {
    dark: true,
    colors: {
      primary: colors.accent,
      background: colors.background,
      card: colors.card,
      text: colors.text,
      border: colors.border,
      notification: colors.accent,
    },
  } as const;

  if (loading) {
    return <SplashScreen />;
  }

  return (
    <NavigationContainer theme={navTheme as any}>
      {!session ? (
        <AuthStackNavigator />
      ) : profile?.role === 'admin' ? (
        <AdminTabNavigator />
      ) : (
        <UserTabNavigator />
      )}
    </NavigationContainer>
  );
}
