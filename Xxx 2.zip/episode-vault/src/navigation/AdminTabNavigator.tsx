import React from 'react';
import { Text } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { colors } from '../theme/colors';

import AdminDashboardScreen from '../screens/admin/AdminDashboardScreen';
import AdminEpisodesScreen from '../screens/admin/AdminEpisodesScreen';
import AddEditEpisodeScreen from '../screens/admin/AddEditEpisodeScreen';
import AdminPaymentsScreen from '../screens/admin/AdminPaymentsScreen';
import ProfileScreen from '../screens/user/ProfileScreen';

export type AdminStackParamList = {
  EpisodesMain: undefined;
  AddEditEpisode: { episodeId?: string };
};

const EpisodesStack = createNativeStackNavigator<AdminStackParamList>();
const Tab = createBottomTabNavigator();

const stackScreenOptions = {
  headerStyle: { backgroundColor: colors.background },
  headerTintColor: colors.text,
  headerShadowVisible: false,
  contentStyle: { backgroundColor: colors.background },
};

function EpisodesStackNavigator() {
  return (
    <EpisodesStack.Navigator screenOptions={stackScreenOptions}>
      <EpisodesStack.Screen
        name="EpisodesMain"
        component={AdminEpisodesScreen}
        options={{ title: 'Episodes' }}
      />
      <EpisodesStack.Screen
        name="AddEditEpisode"
        component={AddEditEpisodeScreen}
        options={{ title: 'Episode' }}
      />
    </EpisodesStack.Navigator>
  );
}

function tabIcon(label: string) {
  return ({ color }: { color: string }) => <Text style={{ color, fontSize: 12 }}>{label}</Text>;
}

export default function AdminTabNavigator() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: { backgroundColor: colors.card, borderTopColor: colors.border },
        tabBarActiveTintColor: colors.accent,
        tabBarInactiveTintColor: colors.textMuted,
      }}
    >
      <Tab.Screen name="Dashboard" component={AdminDashboardScreen} options={{ tabBarIcon: tabIcon('📊') }} />
      <Tab.Screen name="Episodes" component={EpisodesStackNavigator} options={{ tabBarIcon: tabIcon('🎬') }} />
      <Tab.Screen name="Payments" component={AdminPaymentsScreen} options={{ tabBarIcon: tabIcon('💳') }} />
      <Tab.Screen name="Profile" component={ProfileScreen} options={{ tabBarIcon: tabIcon('👤') }} />
    </Tab.Navigator>
  );
}
