import React from 'react';
import { Text } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { colors } from '../theme/colors';

import HomeScreen from '../screens/user/HomeScreen';
import EpisodeDetailsScreen from '../screens/user/EpisodeDetailsScreen';
import PaymentScreen from '../screens/user/PaymentScreen';
import VideoPlayerScreen from '../screens/user/VideoPlayerScreen';
import MyEpisodesScreen from '../screens/user/MyEpisodesScreen';
import ProfileScreen from '../screens/user/ProfileScreen';

export type UserStackParamList = {
  HomeMain: undefined;
  EpisodeDetails: { episodeId: string };
  Payment: { episodeId: string };
  VideoPlayer: { episodeId: string };
};

const HomeStack = createNativeStackNavigator<UserStackParamList>();
const MyEpisodesStack = createNativeStackNavigator<UserStackParamList>();
const Tab = createBottomTabNavigator();

const stackScreenOptions = {
  headerStyle: { backgroundColor: colors.background },
  headerTintColor: colors.text,
  headerShadowVisible: false,
  contentStyle: { backgroundColor: colors.background },
};

function HomeStackNavigator() {
  return (
    <HomeStack.Navigator screenOptions={stackScreenOptions}>
      <HomeStack.Screen name="HomeMain" component={HomeScreen} options={{ title: 'Episode Vault' }} />
      <HomeStack.Screen name="EpisodeDetails" component={EpisodeDetailsScreen} options={{ title: 'Episode' }} />
      <HomeStack.Screen name="Payment" component={PaymentScreen} options={{ title: 'Unlock Episode' }} />
      <HomeStack.Screen name="VideoPlayer" component={VideoPlayerScreen} options={{ title: 'Now Playing' }} />
    </HomeStack.Navigator>
  );
}

function MyEpisodesStackNavigator() {
  return (
    <MyEpisodesStack.Navigator screenOptions={stackScreenOptions}>
      <MyEpisodesStack.Screen name="HomeMain" component={MyEpisodesScreen} options={{ title: 'My Episodes' }} />
      <MyEpisodesStack.Screen name="VideoPlayer" component={VideoPlayerScreen} options={{ title: 'Now Playing' }} />
    </MyEpisodesStack.Navigator>
  );
}

function tabIcon(label: string) {
  return ({ color }: { color: string }) => <Text style={{ color, fontSize: 12 }}>{label}</Text>;
}

export default function UserTabNavigator() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: { backgroundColor: colors.card, borderTopColor: colors.border },
        tabBarActiveTintColor: colors.accent,
        tabBarInactiveTintColor: colors.textMuted,
      }}
    >
      <Tab.Screen name="Home" component={HomeStackNavigator} options={{ tabBarIcon: tabIcon('🏠') }} />
      <Tab.Screen
        name="MyEpisodes"
        component={MyEpisodesStackNavigator}
        options={{ title: 'My Episodes', tabBarIcon: tabIcon('🎬') }}
      />
      <Tab.Screen name="Profile" component={ProfileScreen} options={{ tabBarIcon: tabIcon('👤') }} />
    </Tab.Navigator>
  );
}
