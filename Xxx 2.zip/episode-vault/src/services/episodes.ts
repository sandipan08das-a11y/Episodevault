import { supabase } from '../lib/supabase';
import { Episode } from '../types';

export async function fetchPublishedEpisodes(): Promise<{ data: Episode[]; error: string | null }> {
  try {
    const { data, error } = await supabase
      .from('episodes')
      .select('*')
      .eq('is_published', true)
      .order('episode_number', { ascending: true });
    if (error) return { data: [], error: 'Unable to load episodes.' };
    return { data: (data as Episode[]) || [], error: null };
  } catch (e) {
    return { data: [], error: 'Unable to load episodes.' };
  }
}

export async function fetchAllEpisodesAdmin(): Promise<{ data: Episode[]; error: string | null }> {
  try {
    const { data, error } = await supabase
      .from('episodes')
      .select('*')
      .order('episode_number', { ascending: true });
    if (error) return { data: [], error: 'Unable to load episodes.' };
    return { data: (data as Episode[]) || [], error: null };
  } catch (e) {
    return { data: [], error: 'Unable to load episodes.' };
  }
}

export async function fetchEpisodeById(id: string): Promise<{ data: Episode | null; error: string | null }> {
  try {
    const { data, error } = await supabase.from('episodes').select('*').eq('id', id).single();
    if (error) return { data: null, error: 'Unable to load this episode.' };
    return { data: data as Episode, error: null };
  } catch (e) {
    return { data: null, error: 'Unable to load this episode.' };
  }
}

export async function createEpisode(payload: Omit<Episode, 'id' | 'created_at'>): Promise<{ error: string | null }> {
  try {
    const { error } = await supabase.from('episodes').insert(payload);
    if (error) return { error: 'Unable to create episode.' };
    return { error: null };
  } catch (e) {
    return { error: 'Unable to create episode.' };
  }
}

export async function updateEpisode(id: string, payload: Partial<Episode>): Promise<{ error: string | null }> {
  try {
    const { error } = await supabase.from('episodes').update(payload).eq('id', id);
    if (error) return { error: 'Unable to update episode.' };
    return { error: null };
  } catch (e) {
    return { error: 'Unable to update episode.' };
  }
}

export async function deleteEpisode(id: string): Promise<{ error: string | null }> {
  try {
    const { error } = await supabase.from('episodes').delete().eq('id', id);
    if (error) return { error: 'Unable to delete episode.' };
    return { error: null };
  } catch (e) {
    return { error: 'Unable to delete episode.' };
  }
}
