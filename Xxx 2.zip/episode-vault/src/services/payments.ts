import { supabase } from '../lib/supabase';
import { PaymentRequest, Purchase } from '../types';

export async function hasPendingRequest(
  userId: string,
  episodeId: string
): Promise<{ pending: boolean; error: string | null }> {
  try {
    const { data, error } = await supabase
      .from('payment_requests')
      .select('id')
      .eq('user_id', userId)
      .eq('episode_id', episodeId)
      .eq('status', 'pending')
      .limit(1);
    if (error) return { pending: false, error: 'Unable to check existing payment requests.' };
    return { pending: (data?.length ?? 0) > 0, error: null };
  } catch (e) {
    return { pending: false, error: 'Unable to check existing payment requests.' };
  }
}

export async function submitPaymentRequest(payload: {
  user_id: string;
  episode_id: string;
  amount: number;
  utr: string;
  screenshot_url: string;
}): Promise<{ error: string | null }> {
  try {
    if (!payload.utr.trim()) return { error: 'Please enter your UTR.' };
    if (!payload.screenshot_url) return { error: 'Please select a payment screenshot.' };

    const { pending, error: checkError } = await hasPendingRequest(payload.user_id, payload.episode_id);
    if (checkError) return { error: checkError };
    if (pending) return { error: 'You already have a pending payment request for this episode.' };

    const { error } = await supabase.from('payment_requests').insert({
      user_id: payload.user_id,
      episode_id: payload.episode_id,
      amount: payload.amount,
      utr: payload.utr.trim(),
      screenshot_url: payload.screenshot_url,
      status: 'pending',
    });
    if (error) return { error: 'Payment submission failed.' };
    return { error: null };
  } catch (e) {
    return { error: 'Payment submission failed.' };
  }
}

export async function fetchMyPaymentRequests(
  userId: string
): Promise<{ data: PaymentRequest[]; error: string | null }> {
  try {
    const { data, error } = await supabase
      .from('payment_requests')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    if (error) return { data: [], error: 'Unable to load your payment history.' };
    return { data: (data as PaymentRequest[]) || [], error: null };
  } catch (e) {
    return { data: [], error: 'Unable to load your payment history.' };
  }
}

export async function fetchMyPurchases(userId: string): Promise<{ data: Purchase[]; error: string | null }> {
  try {
    const { data, error } = await supabase.from('purchases').select('*').eq('user_id', userId);
    if (error) return { data: [], error: 'Unable to load your purchases.' };
    return { data: (data as Purchase[]) || [], error: null };
  } catch (e) {
    return { data: [], error: 'Unable to load your purchases.' };
  }
}

export async function isEpisodeUnlocked(userId: string, episodeId: string): Promise<boolean> {
  try {
    const { data, error } = await supabase
      .from('purchases')
      .select('id')
      .eq('user_id', userId)
      .eq('episode_id', episodeId)
      .limit(1);
    if (error) return false;
    return (data?.length ?? 0) > 0;
  } catch (e) {
    return false;
  }
}

export async function fetchAllPaymentRequestsAdmin(): Promise<{ data: PaymentRequest[]; error: string | null }> {
  try {
    const { data, error } = await supabase
      .from('payment_requests')
      .select('*, profiles(full_name), episodes(episode_number, title)')
      .order('created_at', { ascending: false });
    if (error) return { data: [], error: 'Unable to load payment requests.' };
    return { data: (data as unknown as PaymentRequest[]) || [], error: null };
  } catch (e) {
    return { data: [], error: 'Unable to load payment requests.' };
  }
}

/**
 * Approves a payment request and creates the corresponding purchase.
 * Uses a defensive check to avoid duplicate purchases.
 */
export async function approvePaymentRequest(
  request: PaymentRequest
): Promise<{ error: string | null }> {
  try {
    const { data: existing, error: existingError } = await supabase
      .from('purchases')
      .select('id')
      .eq('user_id', request.user_id)
      .eq('episode_id', request.episode_id)
      .limit(1);

    if (existingError) return { error: 'Unable to approve payment.' };

    if (!existing || existing.length === 0) {
      const { error: purchaseError } = await supabase.from('purchases').insert({
        user_id: request.user_id,
        episode_id: request.episode_id,
        payment_request_id: request.id,
        amount: request.amount,
      });
      if (purchaseError) return { error: 'Unable to approve payment.' };
    }

    const { error: updateError } = await supabase
      .from('payment_requests')
      .update({ status: 'approved', reviewed_at: new Date().toISOString() })
      .eq('id', request.id);

    if (updateError) return { error: 'Unable to approve payment.' };
    return { error: null };
  } catch (e) {
    return { error: 'Unable to approve payment.' };
  }
}

export async function rejectPaymentRequest(requestId: string): Promise<{ error: string | null }> {
  try {
    const { error } = await supabase
      .from('payment_requests')
      .update({ status: 'rejected', reviewed_at: new Date().toISOString() })
      .eq('id', requestId);
    if (error) return { error: 'Unable to reject payment.' };
    return { error: null };
  } catch (e) {
    return { error: 'Unable to reject payment.' };
  }
}
