import { supabase } from '../lib/supabase';

const BUCKET = 'payment-screenshots';

/**
 * Uploads a payment screenshot for a given user/episode and returns the
 * storage PATH (not a public URL, since the bucket is private).
 */
export async function uploadPaymentScreenshot(
  userId: string,
  episodeId: string,
  fileUri: string,
  fileExt: string
): Promise<{ path: string | null; error: string | null }> {
  try {
    const response = await fetch(fileUri);
    const arrayBuffer = await response.arrayBuffer();
    const path = `${userId}/${episodeId}-${Date.now()}.${fileExt}`;

    const { error } = await supabase.storage.from(BUCKET).upload(path, arrayBuffer, {
      contentType: `image/${fileExt === 'jpg' ? 'jpeg' : fileExt}`,
      upsert: false,
    });

    if (error) return { path: null, error: 'Screenshot upload failed.' };
    return { path, error: null };
  } catch (e) {
    return { path: null, error: 'Screenshot upload failed.' };
  }
}

/**
 * Admin-only: generates a short-lived signed URL to view a private screenshot.
 * Relies on RLS/storage policies restricting this to admins server-side;
 * this call will fail for non-admins if policies are configured correctly.
 */
export async function getSignedScreenshotUrl(
  path: string,
  expiresInSeconds = 300
): Promise<{ url: string | null; error: string | null }> {
  try {
    const { data, error } = await supabase.storage.from(BUCKET).createSignedUrl(path, expiresInSeconds);
    if (error || !data?.signedUrl) return { url: null, error: 'Unable to load screenshot.' };
    return { url: data.signedUrl, error: null };
  } catch (e) {
    return { url: null, error: 'Unable to load screenshot.' };
  }
}
