import * as FileSystem from 'expo-file-system';
import { supabase } from '../lib/supabase';

async function callMediaFunction(
  body: Record<string, unknown>
): Promise<{ data: any | null; error: string | null }> {
  try {
    const { data: sessionData } = await supabase.auth.getSession();
    const token = sessionData.session?.access_token;
    if (!token) return { data: null, error: 'You must be logged in.' };

    const { data, error } = await supabase.functions.invoke('r2-media', {
      body,
      headers: { Authorization: `Bearer ${token}` },
    });

    if (error) return { data: null, error: error.message || 'Request failed.' };
    if (data?.error) return { data: null, error: data.error };
    return { data, error: null };
  } catch (e) {
    return { data: null, error: 'Request failed. Please check your connection.' };
  }
}

/**
 * Uploads a local video file to R2 via a presigned URL obtained from the
 * r2-media edge function. Returns the object KEY (not a URL) to store in
 * episodes.video_url — the bucket is private, so playback always goes
 * through a freshly-signed URL, never a stored one.
 */
export async function uploadEpisodeVideo(
  localUri: string,
  fileName: string,
  contentType: string,
  onProgress?: (fraction: number) => void
): Promise<{ key: string | null; error: string | null }> {
  const presign = await callMediaFunction({ action: 'presign-upload', fileName, contentType });
  if (presign.error || !presign.data?.uploadUrl || !presign.data?.key) {
    return { key: null, error: presign.error || 'Unable to prepare upload.' };
  }

  try {
    const uploadTask = FileSystem.createUploadTask(
      presign.data.uploadUrl,
      localUri,
      { httpMethod: 'PUT', headers: { 'content-type': contentType } },
      (progress) => {
        if (onProgress && progress.totalBytesExpectedToSend > 0) {
          onProgress(progress.totalBytesSent / progress.totalBytesExpectedToSend);
        }
      }
    );
    const result = await uploadTask.uploadAsync();
    if (!result || result.status < 200 || result.status >= 300) {
      return { key: null, error: 'Video upload failed.' };
    }
    return { key: presign.data.key, error: null };
  } catch (e) {
    return { key: null, error: 'Video upload failed.' };
  }
}

export async function deleteEpisodeVideo(key: string): Promise<{ error: string | null }> {
  const result = await callMediaFunction({ action: 'delete', key });
  return { error: result.error };
}

/** Returns a short-lived signed playback URL for a private R2 object key. */
export async function getSignedVideoViewUrl(key: string): Promise<{ url: string | null; error: string | null }> {
  const result = await callMediaFunction({ action: 'presign-view', key });
  if (result.error || !result.data?.viewUrl) {
    return { url: null, error: result.error || 'Unable to load video.' };
  }
  return { url: result.data.viewUrl, error: null };
}
