export type UserRole = 'user' | 'admin';
export type PaymentStatus = 'pending' | 'approved' | 'rejected';

export interface Profile {
  id: string;
  full_name: string | null;
  role: UserRole;
  created_at: string;
}

export interface Episode {
  id: string;
  episode_number: number;
  title: string;
  description: string | null;
  thumbnail_url: string | null;
  video_url: string | null;
  price: number;
  is_published: boolean;
  created_at: string;
}

export interface PaymentRequest {
  id: string;
  user_id: string;
  episode_id: string;
  amount: number;
  utr: string;
  screenshot_url: string | null;
  status: PaymentStatus;
  created_at: string;
  reviewed_at: string | null;
  // joined fields (admin view)
  profiles?: Pick<Profile, 'full_name'> & { email?: string };
  episodes?: Pick<Episode, 'episode_number' | 'title'>;
}

export interface Purchase {
  id: string;
  user_id: string;
  episode_id: string;
  payment_request_id: string | null;
  amount: number;
  purchased_at: string;
}
