# Episode Vault — Video Upload Setup (Cloudflare R2)

This adds real in-app video upload/delete for admins, backed by a free
Cloudflare R2 bucket. Nothing in the mobile app ever holds R2 secret keys —
they live only as encrypted secrets on Supabase and GitHub.

## 1. Create the R2 bucket (Cloudflare dashboard, works from phone browser)

1. Sign up / log in at https://dash.cloudflare.com → R2 Object Storage.
2. Create a bucket, e.g. `episode-vault-videos`. Leave it private (default).
3. Go to **R2 → Manage API Tokens → Create API Token**.
   - Permissions: **Object Read & Write**, scoped to your bucket.
   - Save the generated **Access Key ID** and **Secret Access Key** — the
     secret is shown only once.
4. Note your **Account ID** (shown on the R2 overview page).

You now have four values: Account ID, Access Key ID, Secret Access Key,
Bucket name.

## 2. Get a Supabase access token + project ref

1. Supabase dashboard → your avatar → **Access Tokens** → generate one
   (this is a personal token used only by GitHub Actions to deploy).
2. Your **Project Ref** is the subdomain in your project URL:
   `https://<PROJECT_REF>.supabase.co`.

## 3. Add GitHub repository secrets

In your GitHub repo → **Settings → Secrets and variables → Actions**, add:

| Secret name              | Value                              |
|---------------------------|-------------------------------------|
| `SUPABASE_ACCESS_TOKEN`   | token from step 2                   |
| `SUPABASE_PROJECT_REF`    | project ref from step 2             |
| `R2_ACCOUNT_ID`           | from step 1                         |
| `R2_ACCESS_KEY_ID`        | from step 1                         |
| `R2_SECRET_ACCESS_KEY`    | from step 1                         |
| `R2_BUCKET`               | your bucket name from step 1        |

## 4. Deploy the edge function

Push to `main` (or run the workflow manually from the **Actions** tab):
**"Deploy Supabase Edge Functions"**. This deploys `supabase/functions/r2-media`
and sets the R2 secrets on the function — no CLI or laptop needed.

## 5. Use it in the app

- **Admin → Episodes → Add/Edit Episode** now has an **Upload Video**
  button with a progress bar, plus **Replace** / **Delete** once a video
  is attached. The `episodes.video_url` column now stores the private R2
  **object key**, not a public link.
- When a user presses **Watch Now**, the app calls the edge function again
  to get a signed URL that expires in 1 hour — the purchase is re-verified
  server-side every time, and the raw R2 URL is never stored or exposed.

## Notes / limits

- R2's free tier is 10 GB storage/month, with **zero egress fees** — so
  streaming costs stay at $0 even as it scales.
- Large video files take a while to upload over mobile data — Wi-Fi is
  recommended for admin uploads.
- If uploads fail with "R2 storage is not configured," double-check the
  four `R2_*` GitHub secrets and re-run the deploy workflow.
