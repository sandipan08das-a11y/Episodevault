-- Episode Vault: Storage RLS policies for the existing PRIVATE bucket
-- "payment-screenshots". Run this in the Supabase SQL editor.
--
-- Assumes: bucket "payment-screenshots" already exists and is private.
-- Assumes: public.is_admin() already exists and returns true for admins.
-- This does NOT touch profiles / episodes / payment_requests / purchases
-- tables or their existing policies, as those already exist per spec.

-- Allow a user to upload only into a folder named after their own user id,
-- e.g. "<user_id>/<episode_id>-<timestamp>.jpg"
create policy "Users can upload own payment screenshots"
on storage.objects for insert
to authenticated
with check (
  bucket_id = 'payment-screenshots'
  and (storage.foldername(name))[1] = auth.uid()::text
);

-- Allow a user to view only their own uploaded screenshots
create policy "Users can view own payment screenshots"
on storage.objects for select
to authenticated
using (
  bucket_id = 'payment-screenshots'
  and (storage.foldername(name))[1] = auth.uid()::text
);

-- Allow admins to view all payment screenshots (for manual verification)
create policy "Admins can view all payment screenshots"
on storage.objects for select
to authenticated
using (
  bucket_id = 'payment-screenshots'
  and public.is_admin()
);

-- No update/delete policies are granted to normal users or admins here;
-- screenshots are kept as an immutable audit trail. Add explicit policies
-- later only if you need admins to delete old screenshots.
