// supabase/functions/r2-media/index.ts
//
// Admin-only broker for Cloudflare R2 video storage.
// Holds R2 credentials as server-side secrets (never shipped to the app).
// The mobile app calls this function with a Supabase auth token; this
// function verifies the caller is an admin (profiles.role = 'admin')
// before issuing a short-lived signed URL for upload, delete, or view.

import { serve } from 'https://deno.land/std@0.224.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.4';
import { AwsClient } from 'https://esm.sh/aws4fetch@1.0.17';

const R2_ACCOUNT_ID = Deno.env.get('R2_ACCOUNT_ID') ?? '';
const R2_ACCESS_KEY_ID = Deno.env.get('R2_ACCESS_KEY_ID') ?? '';
const R2_SECRET_ACCESS_KEY = Deno.env.get('R2_SECRET_ACCESS_KEY') ?? '';
const R2_BUCKET = Deno.env.get('R2_BUCKET') ?? '';

// Auto-provided by the Supabase Edge Functions runtime.
const SUPABASE_URL = Deno.env.get('SUPABASE_URL') ?? '';
const SUPABASE_ANON_KEY = Deno.env.get('SUPABASE_ANON_KEY') ?? '';

const R2_ENDPOINT = `https://${R2_ACCOUNT_ID}.r2.cloudflarestorage.com`;

const r2 = new AwsClient({
  accessKeyId: R2_ACCESS_KEY_ID,
  secretAccessKey: R2_SECRET_ACCESS_KEY,
  service: 's3',
  region: 'auto',
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json' },
  });
}

async function presign(key: string, method: 'PUT' | 'GET' | 'DELETE', contentType?: string, expiresIn = 3600) {
  const url = new URL(`${R2_ENDPOINT}/${R2_BUCKET}/${key}`);
  url.searchParams.set('X-Amz-Expires', String(expiresIn));
  const headers: Record<string, string> = {};
  if (contentType) headers['content-type'] = contentType;
  const signed = await r2.sign(new Request(url.toString(), { method, headers }), {
    aws: { signQuery: true },
  });
  return signed.url;
}

serve(async (req) => {
  if (req.method !== 'POST') {
    return json({ error: 'Method not allowed' }, 405);
  }

  if (!R2_ACCOUNT_ID || !R2_ACCESS_KEY_ID || !R2_SECRET_ACCESS_KEY || !R2_BUCKET) {
    return json({ error: 'R2 storage is not configured on the server.' }, 500);
  }

  try {
    const authHeader = req.headers.get('Authorization') ?? '';
    const token = authHeader.replace('Bearer ', '');
    if (!token) return json({ error: 'Missing auth token.' }, 401);

    const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      global: { headers: { Authorization: `Bearer ${token}` } },
    });

    const { data: userData, error: userError } = await supabase.auth.getUser(token);
    if (userError || !userData?.user) return json({ error: 'Invalid session.' }, 401);

    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', userData.user.id)
      .single();

    if (profileError || profile?.role !== 'admin') {
      return json({ error: 'Admin access required.' }, 403);
    }

    const body = await req.json();
    const { action } = body;

    if (action === 'presign-upload') {
      const { fileName, contentType } = body;
      if (!fileName) return json({ error: 'fileName is required.' }, 400);
      const safeName = String(fileName).replace(/[^a-zA-Z0-9._-]/g, '_');
      const key = `episodes/${crypto.randomUUID()}-${safeName}`;
      const uploadUrl = await presign(key, 'PUT', contentType || 'video/mp4', 900);
      return json({ uploadUrl, key });
    }

    if (action === 'presign-view') {
      const { key } = body;
      if (!key) return json({ error: 'key is required.' }, 400);
      const viewUrl = await presign(key, 'GET', undefined, 3600);
      return json({ viewUrl });
    }

    if (action === 'delete') {
      const { key } = body;
      if (!key) return json({ error: 'key is required.' }, 400);
      const deleteUrl = await presign(key, 'DELETE', undefined, 60);
      const res = await fetch(deleteUrl, { method: 'DELETE' });
      if (!res.ok && res.status !== 404) {
        return json({ error: 'Failed to delete file from storage.' }, 500);
      }
      return json({ success: true });
    }

    return json({ error: 'Unknown action.' }, 400);
  } catch (e) {
    return json({ error: 'Internal error.', details: String(e) }, 500);
  }
});
